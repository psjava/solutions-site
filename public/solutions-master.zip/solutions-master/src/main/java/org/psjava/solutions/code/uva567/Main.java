package org.psjava.solutions.code.uva567;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.PrintStream;

import org.psjava.algo.graph.shortestpath.AllPairShortestPath;
import org.psjava.algo.graph.shortestpath.AllPairShortestPathResult;
import org.psjava.algo.graph.shortestpath.FloydWarshall;
import org.psjava.ds.graph.DirectedWeightedEdge;
import org.psjava.ds.graph.DirectedWeightedGraphFromUndirected;
import org.psjava.ds.graph.Graph;
import org.psjava.ds.graph.MutableUndirectedWeightedGraph;
import org.psjava.ds.numbersystrem.IntegerNumberSystem;
import org.psjava.util.FastScanner;
import org.psjava.util.FromTo;
import org.psjava.util.ZeroTo;

/**
 * UVA 567 - Risk
 * 
 * http://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&page=show_problem&problem=508
 * 
 * Trivial all path shortest path problem. But the all weights are one. Floyd Warshall's algorithm is enough.
 */

public class Main implements Runnable {

	private static final AllPairShortestPath ALGO = new FloydWarshall();

	@SuppressWarnings("unused")
	@Override
	public void run() { 
		FastScanner in = new FastScanner(System.in);

		for (int casei = 1; in.hasNext(); casei++) {

			MutableUndirectedWeightedGraph<Integer, Integer> graph = MutableUndirectedWeightedGraph.create();
			for (int i : FromTo.get(1, 21))
				graph.insertVertex(i);
			for (int from : FromTo.get(1, 20))
				for (int i : ZeroTo.get(in.nextInt()))
					graph.addEdge(from, in.nextInt(), 1);

			Graph<Integer, DirectedWeightedEdge<Integer,Integer>> directed = DirectedWeightedGraphFromUndirected.wrap(graph);

			AllPairShortestPathResult<Integer, Integer, DirectedWeightedEdge<Integer, Integer>> res = ALGO.calc(directed, IntegerNumberSystem.getInstance());

			System.out.println("Test Set #" + casei);
			for (int i : ZeroTo.get(in.nextInt())) {
				int from = in.nextInt();
				int to = in.nextInt();
				System.out.println(format(from) + " to " + format(to) + ": " + res.getDistance(from, to));
			}
			System.out.println();
		}
	}

	private String format(int v) {
		if (v < 10)
			return " " + v;
		else
			return Integer.toString(v);
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		System.setIn(new BufferedInputStream(System.in));
		System.setOut(new PrintStream(new BufferedOutputStream(System.out)));
		new Main().run();
		System.out.flush();
	}

}
