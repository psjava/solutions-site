package org.psjava.solutions.code.spoj203;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.Scanner;

import org.psjava.algo.graph.flownetwork.EdmondsKarpAlgorithm;
import org.psjava.algo.graph.flownetwork.MaximumFlowAlgorithm;
import org.psjava.ds.graph.MutableCapacityGraph;
import org.psjava.ds.numbersystrem.IntegerNumberSystem;
import org.psjava.util.FromTo;
import org.psjava.util.ZeroTo;

/**
 * SPOJ 203 POTHOLE (Potholers) Solution
 * 
 * this problem converted to a simple maximum flow problem. each capacity is 1 or infinite.
 */

public class Main implements Runnable {

	private static final MaximumFlowAlgorithm MAXFLOW = EdmondsKarpAlgorithm.getInstance();
	private static final IntegerNumberSystem NS = IntegerNumberSystem.getInstance();

	@SuppressWarnings("unused")
	@Override
	public void run() {
		Scanner in = new Scanner(new BufferedInputStream(System.in));

		for (int casei : ZeroTo.get(in.nextInt())) {
			MutableCapacityGraph<Integer, Integer> capacityGraph = MutableCapacityGraph.create();
			int n = in.nextInt();
			for (int v : FromTo.get(1, n + 1))
				capacityGraph.insertVertex(v);

			for (int from : FromTo.get(1, n)) {
				for (int j : ZeroTo.get(in.nextInt())) {
					int to = in.nextInt();
					int capacity;
					if (from == 1 || to == n)
						capacity = 1;
					else
						capacity = 1000000;
					capacityGraph.addEdge(from, to, capacity);
				}
			}
			System.out.println(MAXFLOW.calc(capacityGraph, 1, n, NS).calcTotalFlow());
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
