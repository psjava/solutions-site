package org.psjava.solutions.code;

import java.io.FileInputStream;
import java.math.BigInteger;
import java.util.Scanner;

import org.psjava.algo.sequence.search.BinarySearchLastTrue;
import org.psjava.ds.math.Function;
import org.psjava.ds.numbersystrem.BigIntegerNumberSystem;
import org.psjava.formula.ArithmeticSeries;
import org.psjava.util.ZeroTo;

/**
 * Google Code Jam 2013 Round 1A Problem A Solution - Bullseye
 * 
 * Analysis : https://code.google.com/codejam/contest/2418487/dashboard#s=a&a=0
 */

public class GoogleCodeJam2013Round1AProblemASolution implements Runnable {

	private static final BigIntegerNumberSystem NS = BigIntegerNumberSystem.getInstance();

	@Override
	public void run() {
		Scanner in = new Scanner(System.in);
		int casen = in.nextInt();
		for (int casei : ZeroTo.get(casen)) {
			final BigInteger r = BigInteger.valueOf(in.nextLong());
			final BigInteger t = BigInteger.valueOf(in.nextLong());
			BigInteger index = BinarySearchLastTrue.search(NS, new Function<BigInteger, Boolean>() {
				@Override
				public Boolean get(BigInteger n) {
					BigInteger a1 = BigInteger.valueOf(2).multiply(r).add(BigInteger.ONE); // 2R+1
					BigInteger diff = BigInteger.valueOf(4);
					BigInteger sum = ArithmeticSeries.calc(NS, a1, diff, n); // sum of 2R+1, 2R+5, 2R+9, ...
					return sum.compareTo(t) <= 0;
				}
			}, BigInteger.ONE, t.add(BigInteger.ONE), null);
			System.out.printf("Case #%d: %d\n", casei + 1, index);
		}
	}

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input.txt"));
		new GoogleCodeJam2013Round1AProblemASolution().run();
	}

}
