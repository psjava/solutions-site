package org.psjava.solutions.code.spoj3410;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.ds.numbersystrem.IntegerNumberSystem;
import org.psjava.formula.SquarePyramidalNumber;
import org.psjava.util.FastScanner;

/**
 * SPOJ 3410. SAMER08F Solution.
 * 
 * http://www.spoj.com/problems/SAMER08F/
 * 
 * Simple calculation of Square pyramidal number (http://en.wikipedia.org/wiki/Square_pyramidal_number)
 */

public class Main implements Runnable {

	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		while (true) {
			int n = in.nextInt();
			if (n == 0)
				break;
			System.out.println(SquarePyramidalNumber.calc(n, IntegerNumberSystem.getInstance()));
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
