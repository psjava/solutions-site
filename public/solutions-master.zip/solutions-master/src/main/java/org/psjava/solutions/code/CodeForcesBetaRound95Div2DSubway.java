package org.psjava.solutions.code;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.algo.graph.dfs.DFSVisitorBase;
import org.psjava.algo.graph.dfs.MultiSourceDFS;
import org.psjava.algo.graph.dfs.SingleSourceDFS;
import org.psjava.algo.sequence.search.LinearSearch;
import org.psjava.ds.array.DynamicArray;
import org.psjava.ds.array.SubArray;
import org.psjava.ds.graph.AdjacencyList;
import org.psjava.ds.graph.AdjacencyListFromGraph;
import org.psjava.ds.graph.DirectedEdge;
import org.psjava.ds.graph.DirectedGraphFromUndirected;
import org.psjava.ds.graph.EdgeFilteredSubGraph;
import org.psjava.ds.graph.Graph;
import org.psjava.ds.graph.MutableUndirectedGraph;
import org.psjava.ds.graph.UndirectedEdge;
import org.psjava.ds.set.InsertAllToSet;
import org.psjava.ds.set.MutableSet;
import org.psjava.goods.GoodMutableSetFactory;
import org.psjava.util.DataFilter;
import org.psjava.util.FastScanner;
import org.psjava.util.VisitorStopper;
import org.psjava.util.ZeroTo;

/**
 * Solution - Codeforces Beta Round #95 (Div. 2) D. Subway
 * 
 * http://codeforces.com/problemset/problem/131/D
 * 
 * Step 1. Do DFS(depth first search) to find a cycle.
 * 
 * Step 2. Do DFS to find the distances from cycle vertices. In this step, vertices in the cycle are start points.
 */

public class CodeForcesBetaRound95Div2DSubway implements Runnable {

	@SuppressWarnings("unused")
	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		int n = in.nextInt();
		final MutableUndirectedGraph<Integer> graph = MutableUndirectedGraph.create();
		for (int i : ZeroTo.get(n))
			graph.insertVertex(i + 1);
		for (int i : ZeroTo.get(n)) {
			int v1 = in.nextInt();
			int v2 = in.nextInt();
			graph.addEdge(v1, v2);
		}

		final MutableSet<Integer> vertexInCycle = GoodMutableSetFactory.getInstance().create();
		AdjacencyList<Integer, DirectedEdge<Integer>> adj = AdjacencyListFromGraph.create(DirectedGraphFromUndirected.wrap(graph));
		SingleSourceDFS.traverse(adj, 1, new DFSVisitorBase<Integer, DirectedEdge<Integer>>() {
			DynamicArray<Integer> path = DynamicArray.create();

			@Override
			public void onDiscovered(Integer vertex, int depth, VisitorStopper stopper) {
				path.addToLast(vertex);
			}

			@Override
			public void onBackEdgeFound(DirectedEdge<Integer> edge) {
				if (vertexInCycle.isEmpty() && !edge.to().equals(path.get(path.size() - 2))) {
					int pos = LinearSearch.search(path, edge.to(), -1);
					InsertAllToSet.insertAll(vertexInCycle, SubArray.wrap(path, pos, path.size()));
				}
			}

			@Override
			public void onFinish(Integer vertex, int depth) {
				path.removeLast();
			}
		});

		Graph<Integer, UndirectedEdge<Integer>> edgesInCycleRemoved = EdgeFilteredSubGraph.wrap(graph, new DataFilter<UndirectedEdge<Integer>>() {
			@Override
			public boolean isAccepted(UndirectedEdge<Integer> v) {
				return !(vertexInCycle.contains(v.v1()) && vertexInCycle.contains(v.v2()));
			}
		});

		final int[] distance = new int[n];

		MultiSourceDFS.traverse(DirectedGraphFromUndirected.wrap(edgesInCycleRemoved), vertexInCycle, new DFSVisitorBase<Integer, DirectedEdge<Integer>>() {
			@Override
			public void onDiscovered(Integer vertex, int depth, VisitorStopper stopper) {
				distance[vertex - 1] = depth;
			}
		});

		for (int d : distance)
			System.out.print(d + " ");
		System.out.println();
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new CodeForcesBetaRound95Div2DSubway().run();
	}

}
