package org.psjava.solutions.code;

import java.io.BufferedInputStream;

import org.psjava.algo.graph.shortestpath.SingleSourceShortestPath;
import org.psjava.algo.graph.shortestpath.SingleSourceShortestPathResult;
import org.psjava.ds.graph.DirectedWeightedEdge;
import org.psjava.ds.graph.MutableDirectedWeightedGraph;
import org.psjava.ds.numbersystrem.LongNumberSystem;
import org.psjava.goods.GoodSingleSourceShortestPath;
import org.psjava.util.FastScanner;
import org.psjava.util.ZeroTo;

public class CodeForcesAlphaRound20CDijkstra implements Runnable {

	/**
	 * Codeforces Alpha Round #20 C. Dijkstra? Solution
	 * 
	 * http://codeforces.com/contest/20/problem/C
	 * 
	 * This is trivial shortest path problem. Use Dijkstra's Algorithm.
	 */

	private static final SingleSourceShortestPath ALGO = GoodSingleSourceShortestPath.getInstance();

	@SuppressWarnings("unused")
	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		int n = in.nextInt();
		int m = in.nextInt();
		MutableDirectedWeightedGraph<Integer, Long> g = MutableDirectedWeightedGraph.create();
		for (int i : ZeroTo.get(n))
			g.insertVertex(i + 1);
		for (int i : ZeroTo.get(m)) {
			int v1 = in.nextInt();
			int v2 = in.nextInt();
			long w = in.nextInt();
			g.addEdge(v1, v2, w);
			g.addEdge(v2, v1, w);
		}

		SingleSourceShortestPathResult<Integer, Long, DirectedWeightedEdge<Integer, Long>> r = ALGO.calc(g, 1, LongNumberSystem.getInstance());
		if (r.isReachable(n)) {
			for (DirectedWeightedEdge<Integer, Long> e : r.getPath(n))
				System.out.print(e.from() + " ");
			System.out.println(n);
		} else {
			System.out.println(-1);
		}
	}

	public static void main(String[] args) throws Exception {
		new CodeForcesAlphaRound20CDijkstra().run();
	}

}
