package org.psjava.solutions.template;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.PrintStream;

import org.psjava.util.FastScanner;

public class UVATemplate implements Runnable {

	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in)); // use Scanner if it's enough
		in.nextInt();
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		System.setIn(new BufferedInputStream(System.in));
		System.setOut(new PrintStream(new BufferedOutputStream(System.out)));
		new UVATemplate().run();
		System.out.flush();
	}

}
