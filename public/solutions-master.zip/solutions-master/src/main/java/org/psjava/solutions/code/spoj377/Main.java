package org.psjava.solutions.code.spoj377;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.algo.graph.matching.HopcroftKarpAlgorithm;
import org.psjava.algo.graph.matching.MaximumBipartiteMatchingResult;
import org.psjava.ds.graph.MutableBipartiteGraph;
import org.psjava.util.FastScanner;
import org.psjava.util.ZeroTo;

public class Main implements Runnable {

	/**
	 * SPOJ 377 - TAXI - Solution
	 * 
	 * http://www.spoj.com/problems/TAXI/
	 */

	@SuppressWarnings("unused")
	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		for (int casei : ZeroTo.get(in.nextInt())) {
			int p = in.nextInt();
			int t = in.nextInt();
			int s = in.nextInt();
			int c = in.nextInt();

			int[] px = new int[p];
			int[] py = new int[p];
			for (int i : ZeroTo.get(p)) {
				px[i] = in.nextInt();
				py[i] = in.nextInt();
			}

			int[] tx = new int[t];
			int[] ty = new int[t];
			for (int i : ZeroTo.get(t)) {
				tx[i] = in.nextInt();
				ty[i] = in.nextInt();
			}

			MutableBipartiteGraph<Integer> g = MutableBipartiteGraph.create();
			for (int i : ZeroTo.get(p))
				g.insertLeftVertex(i);
			for (int i : ZeroTo.get(t))
				g.insertRightVertex(p + i);
			for (int i : ZeroTo.get(p))
				for (int j : ZeroTo.get(t))
					if (200 * (Math.abs(px[i] - tx[j]) + Math.abs(py[i] - ty[j])) <= s * c)
						g.addEdge(i, p + j);

			MaximumBipartiteMatchingResult<Integer> r = HopcroftKarpAlgorithm.getInstance().calc(g);
			System.out.println(r.getMaxMatchCount());
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
