package org.psjava.solutions.code;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.Scanner;

import org.psjava.algo.sequence.sort.SortingAlgorithm;
import org.psjava.ds.array.AddToLastAll;
import org.psjava.ds.array.DynamicArray;
import org.psjava.ds.array.MutableArrayUsingIntArray;
import org.psjava.ds.array.UniformArray;
import org.psjava.ds.map.MutableMap;
import org.psjava.ds.map.MutableMapFactory;
import org.psjava.ds.math.BinaryOperator;
import org.psjava.ds.tree.segmenttree.SegmentTree;
import org.psjava.ds.tree.segmenttree.SegmentTreeFactory;
import org.psjava.goods.GoodMutableMapFactory;
import org.psjava.goods.GoodSegmentTreeFactory;
import org.psjava.goods.GoodSortingAlgorithm;
import org.psjava.util.DefaultComparator;
import org.psjava.util.ZeroTo;

/**
 * Google Code Jam 2008 Round 1C Problem C Solution - Increasing Speed Limits
 * 
 * Analysis : https://code.google.com/codejam/contest/32015/dashboard#s=a&a=2
 */

public class GoogleCodeJam2008Round1CProblemCSolution {

	private static final MutableMapFactory MF = GoodMutableMapFactory.getInstance();
	private static final SortingAlgorithm SORT = GoodSortingAlgorithm.getInstance();
	private static final SegmentTreeFactory STF = GoodSegmentTreeFactory.getInstance();

	private static final long M = 1000000007L;

	public static void solve() {
		Scanner in = new Scanner(System.in);
		int casen = in.nextInt();
		for (int casei : ZeroTo.get(casen)) {
			int n = in.nextInt();
			int m = in.nextInt();
			long x = in.nextInt();
			long y = in.nextInt();
			long z = in.nextInt();

			long[] a = new long[m];
			for (int i : ZeroTo.get(m))
				a[i] = in.nextInt();

			int[] s = generate(n, m, x, y, z, a);

			normalize(s);

			SegmentTree<Long> tree = STF.create(UniformArray.create(0L, n), new BinaryOperator<Long>() {
				@Override
				public Long calc(Long a, Long b) {
					return (a + b) % M;
				}
			});

			for (int i = n - 1; i >= 0; i--) {
				long addition = 1;
				if (s[i] + 1 < n)
					addition += tree.query(s[i] + 1, n);
				tree.update(s[i], (tree.query(s[i], s[i] + 1) + addition) % M);
			}

			long tot = 0;
			for (int i : ZeroTo.get(n))
				tot = (tot + tree.query(i, i + 1)) % M;

			System.out.println("Case #" + (casei + 1) + ": " + tot);
		}
	}

	private static int[] generate(int n, int m, long x, long y, long z, long[] a) {
		int[] s = new int[n];
		for (int i : ZeroTo.get(n)) {
			s[i] = (int) a[i % m];
			a[i % m] = (x * a[i % m] + y * (i + 1)) % z;
		}
		return s;
	}

	private static void normalize(int[] s) {
		DynamicArray<Integer> all = DynamicArray.create();
		AddToLastAll.add(all, MutableArrayUsingIntArray.wrap(s));
		SORT.sort(all, new DefaultComparator<Integer>());
		MutableMap<Integer, Integer> map = MF.create();
		for (int i : ZeroTo.get(all.size()))
			if (i == 0 || all.get(i) != all.get(i - 1))
				map.put(all.get(i), i);
		for (int i : ZeroTo.get(s.length))
			s[i] = map.get(s[i]);
	}

	public static void main(String[] args) throws Exception {
		System.setIn(new BufferedInputStream(new FileInputStream("input.txt")));
		GoogleCodeJam2008Round1CProblemCSolution.solve();
	}

}
