package org.psjava.solutions.template;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.util.FastScanner;

public class OtherTemplate implements Runnable {

	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in)); // use Scanner if it's enough
		in.nextInt();
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new OtherTemplate().run();
	}

}
