package org.psjava.solutions.code.spoj1841;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.algo.graph.bfs.BFS;
import org.psjava.algo.graph.bfs.BFSVisitor;
import org.psjava.algo.math.numbertheory.PrimalityTester;
import org.psjava.algo.math.numbertheory.PrimalityTesterBySieve;
import org.psjava.algo.math.numbertheory.SieveOfEratosthenes;
import org.psjava.ds.array.DynamicArray;
import org.psjava.ds.graph.AdjacencyList;
import org.psjava.ds.graph.AdjacencyListFromGraph;
import org.psjava.ds.graph.DirectedEdge;
import org.psjava.ds.graph.MutableDirectedGraph;
import org.psjava.util.DataKeeper;
import org.psjava.util.FastScanner;
import org.psjava.util.FromTo;
import org.psjava.util.SingleElementCollection;
import org.psjava.util.VisitorStopper;
import org.psjava.util.ZeroTo;

/**
 * SPOJ 1841 - PPATH Solution
 * 
 * http://www.spoj.com/problems/PPATH/
 * 
 * Construct a graph using primes, then the problem is simple bfs problem.
 */

public class Main implements Runnable {

	private static final PrimalityTester PRIMALITY_TESTER = PrimalityTesterBySieve.create(SieveOfEratosthenes.getInstance(), 10000);

	@SuppressWarnings("unused")
	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));

		DynamicArray<Integer> primes = DynamicArray.create();
		for (int i : FromTo.get(1000, 9999 + 1))
			if (PRIMALITY_TESTER.isPrime(i))
				primes.addToLast(i);

		MutableDirectedGraph<Integer> graph = MutableDirectedGraph.create();
		for (int i : primes)
			graph.insertVertex(i);
		for (int i : primes)
			for (int j : primes)
				if (countDiff(i, j) == 1)
					graph.addEdge(i, j);

		AdjacencyList<Integer, DirectedEdge<Integer>> adj = AdjacencyListFromGraph.create(graph);

		for (int i : ZeroTo.get(in.nextInt())) {
			final int v1 = in.nextInt();
			final int v2 = in.nextInt();
			final DataKeeper<Integer> result = DataKeeper.create(-1);
			BFS.traverse(adj, SingleElementCollection.create(v1), new BFSVisitor<Integer, DirectedEdge<Integer>>() {
				@Override
				public void onDiscover(Integer vertex, int depth, VisitorStopper stopper) {
					if (vertex == v2) {
						result.set(depth);
						stopper.stop();
					}
				}

				@Override
				public void onWalk(DirectedEdge<Integer> e) {
				}
			});
			if (result.get() == -1)
				System.out.println("Impossible");
			else
				System.out.println(result.get());
		}

	}

	@SuppressWarnings("unused")
	private int countDiff(int v1, int v2) {
		int diff = 0;
		for (int k : ZeroTo.get(4)) {
			if (v1 % 10 != v2 % 10)
				diff++;
			v1 /= 10;
			v2 /= 10;
		}
		return diff;
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
