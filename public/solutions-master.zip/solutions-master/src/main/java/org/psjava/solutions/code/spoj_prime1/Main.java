package org.psjava.solutions.code.spoj_prime1;

import java.io.FileInputStream;
import java.util.Scanner;

import org.psjava.algo.math.numbertheory.SieveOfEratosthenes;
import org.psjava.ds.array.Array;
import org.psjava.util.ZeroTo;

/**
 * @title Prime Generator
 * 
 * @hint Basically, test primality by trivial division method. but time limit is very tight.
 * @hint So at first, prepare primes, and use them only in the division test. This way makes the test 10 times faster.
 * @hint primes which are smaller than or equal to the square root of the max value are enough, so simple prime sieve method is enough.
 */

public class Main implements Runnable {

	private Array<Integer> primes = SieveOfEratosthenes.getInstance().calcList((int) Math.sqrt(1000000000) + 1);

	@SuppressWarnings("unused")
	@Override
	public void run() {
		Scanner in = new Scanner(System.in);
		for (int casei : ZeroTo.get(in.nextInt())) {
			int s = in.nextInt();
			int e = in.nextInt();
			for (int i = s; i <= e; i++)
				if (isPrime(i))
					System.out.println(i);
			System.out.println();
		}
	}

	public boolean isPrime(int value) {
		if (value <= 1)
			return false;
		for (int i = 0; i < primes.size(); i++) {
			int prime = primes.get(i);
			if (prime * prime > value)
				break;
			if (value % prime == 0)
				return false;
		}
		return true;
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
