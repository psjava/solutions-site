package org.psjava.solutions.code.uva558;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.algo.graph.shortestpath.NegativeCycleFinder;
import org.psjava.ds.graph.MutableDirectedWeightedGraph;
import org.psjava.ds.numbersystrem.IntegerNumberSystem;
import org.psjava.util.FastScanner;
import org.psjava.util.ZeroTo;

public class Main implements Runnable {

	/**
	 * UVA 558 Wormholes. 
	 * 
	 * Trivial problem to find negative cycle in a graph.
	 * 
	 * http://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=499
	 */

	private static final IntegerNumberSystem NS = IntegerNumberSystem.getInstance();

	@SuppressWarnings("unused")
	@Override
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		for (int casei : ZeroTo.get(in.nextInt())) {
			int n = in.nextInt();
			int m = in.nextInt();
			MutableDirectedWeightedGraph<Integer, Integer> g = MutableDirectedWeightedGraph.create();
			for (int i : ZeroTo.get(n))
				g.insertVertex(i);
			for (int i : ZeroTo.get(m)) {
				int from = in.nextInt();
				int to = in.nextInt();
				int weight = in.nextInt();
				g.addEdge(from, to, weight);
			}

			System.out.println(NegativeCycleFinder.find(g, NS).hasCycle() ? "possible" : "not possible");
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
