package org.psjava.solutions.code.uva820;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.psjava.algo.graph.flownetwork.EdmondsKarpAlgorithm;
import org.psjava.algo.graph.flownetwork.MaximumFlowAlgorithm;
import org.psjava.ds.graph.MutableCapacityGraph;
import org.psjava.ds.numbersystrem.IntegerNumberSystem;
import org.psjava.util.FromTo;
import org.psjava.util.ZeroTo;

/**
 * UVA 820 Internet Bandwidth - Solution
 * 
 * Trivial maximum flow problem.
 */

public class Main implements Runnable {

	private static final MaximumFlowAlgorithm MAX_FLOW = EdmondsKarpAlgorithm.getInstance();

	@SuppressWarnings("unused")
	@Override
	public void run() {
		Scanner in = new Scanner(new BufferedInputStream(System.in));
		for (int casei = 1;; casei++) {
			int n = in.nextInt();
			if (n == 0)
				break;
			int source = in.nextInt();
			int destination = in.nextInt();

			MutableCapacityGraph<Integer, Integer> capacityGraph = MutableCapacityGraph.create();
			for (int i : FromTo.get(1, n + 1))
				capacityGraph.insertVertex(i);

			int m = in.nextInt();
			for (int i : ZeroTo.get(m)) {
				int node1 = in.nextInt();
				int node2 = in.nextInt();
				int bandwidth = in.nextInt();
				capacityGraph.addEdge(node1, node2, bandwidth);
				capacityGraph.addEdge(node2, node1, bandwidth);
			}

			int maxFlow = MAX_FLOW.calc(capacityGraph, source, destination, IntegerNumberSystem.getInstance()).calcTotalFlow();

			System.out.println("Network " + casei);
			System.out.println("The bandwidth is " + maxFlow + ".");
			System.out.println();
		}

	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		System.setIn(new BufferedInputStream(System.in));
		System.setOut(new PrintStream(new BufferedOutputStream(System.out)));
		new Main().run();
		System.out.flush();
	}

}
