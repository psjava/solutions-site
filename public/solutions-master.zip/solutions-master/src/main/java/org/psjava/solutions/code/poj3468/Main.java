package org.psjava.solutions.code.poj3468;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import org.psjava.ds.array.MutableArray;
import org.psjava.ds.array.MutableArrayFactory;
import org.psjava.ds.tree.segmenttree.EnhancedRangeUpdatableSegmentTree;
import org.psjava.ds.tree.segmenttree.EnhancedRangeUpdatableSegmentTreeOperator;
import org.psjava.util.FastScanner;
import org.psjava.util.ZeroTo;

public class Main implements Runnable {

	/**
	 * POJ 3468 Solution - A Simple Problem with Integers.
	 * 
	 * Use range updatable segment tree (lazy propagation)
	 */

	@SuppressWarnings("unused")
	public void run() {
		FastScanner in = new FastScanner(new BufferedInputStream(System.in));
		int n = in.nextInt();
		int q = in.nextInt();
		MutableArray<Long> a = MutableArrayFactory.create(n, 0L);
		for (int i : ZeroTo.get(n))
			a.set(i, in.nextLong());

		EnhancedRangeUpdatableSegmentTree<Long, Long> tree = new EnhancedRangeUpdatableSegmentTree<Long, Long>(a, new EnhancedRangeUpdatableSegmentTreeOperator<Long, Long>() {
			@Override
			public Long mergeSingleValue(Long v1, Long v2) {
				return v1 + v2;
			}

			@Override
			public Long mergeRangeValue(Long oldValue, int rangeSize, Long updateData) {
				return oldValue + rangeSize * updateData;
			}

			@Override
			public Long mergeUpdateData(Long oldValue, Long newValue) {
				return oldValue + newValue;
			}
		});

		for (int i : ZeroTo.get(q)) {
			String code = in.next();
			int s = in.nextInt() - 1;
			int e = in.nextInt();
			if (code.equals("C"))
				tree.updateRange(s, e, in.nextLong());
			else
				System.out.println(tree.queryRange(s, e));
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length >= 1)
			System.setIn(new FileInputStream(args[0]));
		new Main().run();
	}

}
