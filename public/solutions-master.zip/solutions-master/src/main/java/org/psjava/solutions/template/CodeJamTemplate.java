package org.psjava.solutions.template;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.Scanner;

public class CodeJamTemplate implements Runnable {

	@Override
	public void run() {
		Scanner in = new Scanner(System.in);
		in.nextInt();
	}

	public static void main(String[] args) throws Exception {
		System.setIn(new BufferedInputStream(new FileInputStream("input.txt")));
		new CodeJamTemplate().run();
	}

}
