package org.psjava.solutions.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Assert;

public class TestUtil {
	
	public static void assertSampleInputOutput(Object objectForFileName, Runnable runnable) {
		try {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			PrintStream out = new PrintStream(os);
			System.setIn(TestUtil.getTestInputStream(objectForFileName, ".in.txt"));
			System.setOut(out);
			runnable.run();
			out.close();
			os.close();
			InputStream result = new ByteArrayInputStream(os.toByteArray());
			InputStream expected = TestUtil.getTestInputStream(objectForFileName, ".out.txt");
			Assert.assertEquals(toLines(expected), toLines(result));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static InputStream getTestInputStream(Object obj, String postFix) {
		String url = "/" + obj.getClass().getName().replace('.', '/') + postFix;
		InputStream r = TestUtil.class.getResourceAsStream(url);
		Assert.assertNotNull(url + " is not found", r);
		return r;
	}

	private static ArrayList<String> toLines(InputStream is) {
		ArrayList<String> lines = new ArrayList<String>();
		Scanner in = new Scanner(is);
		while (in.hasNextLine()) {
			String line = in.nextLine().trim();
			if (line.length() > 0)
				lines.add(line);
		}
		return lines;
	}

}
