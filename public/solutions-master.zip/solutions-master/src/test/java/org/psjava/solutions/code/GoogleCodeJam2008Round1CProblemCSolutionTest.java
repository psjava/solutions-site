package org.psjava.solutions.code;

import org.junit.Test;
import org.psjava.solutions.code.GoogleCodeJam2008Round1CProblemCSolution;
import org.psjava.solutions.util.TestUtil;



public class GoogleCodeJam2008Round1CProblemCSolutionTest {
	
	@Test
	public void test() {
		TestUtil.assertSampleInputOutput(this, new Runnable() {
			@Override
			public void run() {
				GoogleCodeJam2008Round1CProblemCSolution.solve();
			}
		});
	}

}
