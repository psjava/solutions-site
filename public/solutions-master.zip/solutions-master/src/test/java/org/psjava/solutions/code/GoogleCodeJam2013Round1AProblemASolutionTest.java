package org.psjava.solutions.code;

import org.junit.Test;
import org.psjava.solutions.code.GoogleCodeJam2013Round1AProblemASolution;
import org.psjava.solutions.util.TestUtil;

public class GoogleCodeJam2013Round1AProblemASolutionTest {

	@Test
	public void test() throws Exception {
		TestUtil.assertSampleInputOutput(this, new GoogleCodeJam2013Round1AProblemASolution());
	}
}
