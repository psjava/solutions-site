package org.psjava.solutions.code;

import org.junit.Test;
import org.psjava.solutions.util.TestUtil;

public class CodeForcesAlphaRound20CDijkstraTest {
	@Test
	public void test() {
		TestUtil.assertSampleInputOutput(this, new CodeForcesAlphaRound20CDijkstra());
	}
}
