package org.psjava.solutions.code.spoj3410;

import org.junit.Test;
import org.psjava.solutions.util.TestUtil;

public class MainTest {
	@Test
	public void test() {
		TestUtil.assertSampleInputOutput(this, new Main());
	}
}
