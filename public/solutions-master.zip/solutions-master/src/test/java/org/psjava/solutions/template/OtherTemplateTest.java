package org.psjava.solutions.template;

import org.junit.Test;
import org.psjava.solutions.template.OtherTemplate;
import org.psjava.solutions.util.TestUtil;

public class OtherTemplateTest {

	@Test
	public void test() {
		TestUtil.assertSampleInputOutput(this, new OtherTemplate());
	}

}
