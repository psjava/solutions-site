package org.psjava.solutions.code;

import org.junit.Test;
import org.psjava.solutions.util.TestUtil;

public class CodeForcesBetaRound95Div2DSubwayTest {

	@Test
	public void test() {
		TestUtil.assertSampleInputOutput(this, new CodeForcesBetaRound95Div2DSubway());
	}

}