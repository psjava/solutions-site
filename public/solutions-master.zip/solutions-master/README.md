See the great library [psjava](http://psjava.org)!

* See [list of solutions](/src/main/java/org/psjava/solutions/code)
